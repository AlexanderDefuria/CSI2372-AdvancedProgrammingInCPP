//
// Alexander De Furia
// 300190815
// 2021-10-04.
//

#include <iostream>
#include "predictor.h"
#include "highscoremanager.h"

int main() {

    menu();
    /* Q1
    int age;
    char sexS;

    std::cout << "Enter an age followed by a sex(M/F) ie '39F'. " << std::endl;
    std::cout << "Age: ";
    std::cin >> age;
    std::cout << "Sex: ";
    std::cin >> sexS;

    std::cout << std::endl<< simulate(age, sexS=='M');
    */

    return 0;
}
