//
// Created by defur on 2021-09-30.
//

#ifndef ASSIGNMENT1_PREDICTOR_H
#define ASSIGNMENT1_PREDICTOR_H
#define MAX_AGE 120

int simulate (int age, bool male);
void load(int *dest , bool male);

#endif //ASSIGNMENT1_PREDICTOR_H
